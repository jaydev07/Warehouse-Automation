#!/usr/bin/env python

import rospy
import cv2
import sys

import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg
import actionlib
import rospkg

import yaml
import os
import math
import time
import copy

from std_msgs.msg import String
from sensor_msgs.msg import Image
from hrwros_gazebo.msg import LogicalCameraImage
from cv_bridge import CvBridge, CvBridgeError

from pkg_vb_sim.srv import vacuumGripper
from pkg_vb_sim.srv import vacuumGripperRequest
from pkg_vb_sim.srv import vacuumGripperResponse

from pkg_vb_sim.srv import conveyorBeltPowerMsg

from std_srvs.srv import Empty

from pyzbar.pyzbar import decode

from pkg_t2_examples.msg import myMessage

from pkg_vb_sim.msg import LogicalCameraImage


from pkg_t2_examples.msg import myMessage

box_length = 0.15               # Length of the Package
vacuum_gripper_width = 0.115    # Vacuum Gripper Width
delta = vacuum_gripper_width + (box_length/2)  # 0.19
        # Teams may use this info in Tasks

ur5_2_home_pose = geometry_msgs.msg.Pose()
ur5_2_home_pose.position.x = -0.8
ur5_2_home_pose.position.y = 0
ur5_2_home_pose.position.z = 1 + vacuum_gripper_width + (box_length/2)
        # This to keep EE parallel to Ground Plane
ur5_2_home_pose.orientation.x = -0.5
ur5_2_home_pose.orientation.y = -0.5
ur5_2_home_pose.orientation.z = 0.5
ur5_2_home_pose.orientation.w = 0.5

message_reveived = False

######################## My Topic variables #################################

msg_received_bySub = True
subscriber_msg = []

#################### Used in Logical Camera 2 Variables #####################

pkg_detected_byLc = []
blt_speed = -1

######################### Publish Variables ###############################

package_found=None
msg_ready = True

######################################## Common Motions ###############################

lst_joint_angles_straigntUp = [math.radians(0),
                      math.radians(-90),
                      math.radians(0),
                      math.radians(0),
                      math.radians(0),
                      math.radians(0)]

lst_joint_angles_home = [math.radians(180),
                      math.radians(-40),
                      math.radians(40),
                      math.radians(-90),
                      math.radians(-90),
                      math.radians(0)]


######################################### 1st ROW ###################################

############# PKG 00 ################# Incomplete

lst_joint_angles_00_2 = [math.radians(-66),
                      math.radians(-66.8),
                      math.radians(-10.3),
                      math.radians(-92.3),
                      math.radians(-116.78),
                      math.radians(-72.8)]

lst_joint_angles_00_3 = [math.radians(-49.4),
                      math.radians(-74.2),
                      math.radians(-4.36),
                      math.radians(-158.2),
                      math.radians(-133),
                      math.radians(-68.6)]

############# PKG 01 #################

lst_joint_angles_01_2 = [math.radians(118.9),
                      math.radians(-114.7),
                      math.radians(23.1),
                      math.radians(-87),
                      math.radians(59.7),
                      math.radians(3.7)]

lst_joint_angles_01_3 = [math.radians(161.82),
                      math.radians(-110),
                      math.radians(35.9),
                      math.radians(-47),
                      math.radians(74.7),
                      math.radians(-6.8)]

############# PKG 02 #################

lst_joint_angles_02_2 = [math.radians(70),
                      math.radians(-130),
                      math.radians(35),
                      math.radians(-70),
                      math.radians(90),
                      math.radians(0)]

lst_joint_angles_02_3 = [math.radians(70),
                      math.radians(-130),
                      math.radians(35),
                      math.radians(0),
                      math.radians(70),
                      math.radians(0)]

######################################## 2rd ROW ###################################

############ PKG 10 #################

lst_joint_angles_10_2 = [math.radians(-52.4),
                      math.radians(-94.2),
                      math.radians(79),
                      math.radians(-172.5),
                      math.radians(-127.4),
                      math.radians(10.6)]

lst_joint_angles_10_3 = [math.radians(-28),
                      math.radians(-102),
                      math.radians(88),
                      math.radians(-179),
                      math.radians(-135),
                      math.radians(3.87)]

############ PKG 11 #################

lst_joint_angles_11_2 = [math.radians(121.8),
                      math.radians(-66.2),
                      math.radians(-97),
                      math.radians(-20.8),
                      math.radians(58),
                      math.radians(-7.27)]

lst_joint_angles_11_3 = [math.radians(137.5),
                      math.radians(-28),
                      math.radians(-58),
                      math.radians(-99),
                      math.radians(42),
                      math.radians(-5.6)]

############ PKG 12 #################

lst_joint_angles_12_2 = [math.radians(57),
                      math.radians(-83.4),
                      math.radians(-80.7),
                      math.radians(-17),
                      math.radians(122.5),
                      math.radians(-3.8)]

lst_joint_angles_12_3 = [math.radians(34.5),
                      math.radians(-73.4),
                      math.radians(-88),
                      math.radians(-19.5),
                      math.radians(145),
                      math.radians(-4.31)]


######################################## 3rd ROW ###################################

############ PKG 20 #################

lst_joint_angles_20_2 = [math.radians(-56.08),
                      math.radians(-91.7),
                      math.radians(-116.8),
                      math.radians(156),
                      math.radians(-124.4),
                      math.radians(-2.58)]

lst_joint_angles_20_3 = [math.radians(-40),
                      math.radians(-101.3),
                      math.radians(124.8),
                      math.radians(158),
                      math.radians(-140.47),
                      math.radians(-2.1)]

############ PKG 21 #################

lst_joint_angles_21_2 = [math.radians(122),
                      math.radians(-63.9),
                      math.radians(-102.7),
                      math.radians(165.5),
                      math.radians(-57.5),
                      math.radians(177.4)]

lst_joint_angles_21_3 = [math.radians(162),
                      math.radians(-45),
                      math.radians(-108.7),
                      math.radians(150.6),
                      math.radians(-17.3),
                      math.radians(179.78)]

############ PKG 22 #######################

lst_joint_angles_22_2 = [math.radians(55.55),
                      math.radians(-82.9),
                      math.radians(-114.7),
                      math.radians(10),
                      math.radians(124),
                      math.radians(-4.12)]

lst_joint_angles_22_3 = [math.radians(36),
                      math.radians(-71.34),
                      math.radians(-120.83),
                      math.radians(1.61),
                      math.radians(143.2),
                      math.radians(-8.35)]



################################################################################  Ur5_moveit Class ##################################################################################################

class Ur5Moveit:

    # Constructor
    def __init__(self, arg_robot_name):

        #rospy.init_node('node_eg4_go_to_pose', anonymous=True)

        self._robot_ns = '/'  + arg_robot_name
        self._planning_group = "manipulator"
        
        self._commander = moveit_commander.roscpp_initialize(sys.argv)
        self._robot = moveit_commander.RobotCommander(robot_description= self._robot_ns + "/robot_description", ns=self._robot_ns)
        self._scene = moveit_commander.PlanningSceneInterface(ns=self._robot_ns)
        self._group = moveit_commander.MoveGroupCommander(self._planning_group, robot_description= self._robot_ns + "/robot_description", ns=self._robot_ns)
        self._display_trajectory_publisher = rospy.Publisher( self._robot_ns + '/move_group/display_planned_path', moveit_msgs.msg.DisplayTrajectory, queue_size=1)
        self._exectute_trajectory_client = actionlib.SimpleActionClient( self._robot_ns + '/execute_trajectory', moveit_msgs.msg.ExecuteTrajectoryAction)
        self._exectute_trajectory_client.wait_for_server()

        self._planning_frame = self._group.get_planning_frame()
        self._eef_link = self._group.get_end_effector_link()
        self._group_names = self._robot.get_group_names()
        self._box_name = ''


        # Attribute to store computed trajectory by the planner	
        self._computed_plan = ''

        # Current State of the Robot is needed to add box to planning scene
        self._curr_state = self._robot.get_current_state()

        rospy.loginfo(
            '\033[94m' + "Planning Group: {}".format(self._planning_frame) + '\033[0m')
        rospy.loginfo(
            '\033[94m' + "End Effector Link: {}".format(self._eef_link) + '\033[0m')
        rospy.loginfo(
            '\033[94m' + "Group Names: {}".format(self._group_names) + '\033[0m')


        rp = rospkg.RosPack()
        self._pkg_path = rp.get_path('pkg_moveit_examples')
        self._file_path = self._pkg_path + '/config/saved_trajectories/'
        rospy.loginfo( "Package Path: {}".format(self._file_path) )


        rospy.loginfo('\033[94m' + " >>> Ur5Moveit init done." + '\033[0m')

    def clear_octomap(self):
        clear_octomap_service_proxy = rospy.ServiceProxy(self._robot_ns + "/clear_octomap", Empty)
        return clear_octomap_service_proxy()

    def set_joint_angles(self, arg_list_joint_angles):

        list_joint_values = self._group.get_current_joint_values()
        # rospy.loginfo('\033[94m' + ">>> Current Joint Values:" + '\033[0m')
        # rospy.loginfo(list_joint_values)

        self._group.set_joint_value_target(arg_list_joint_angles)
        self._computed_plan = self._group.plan()
        flag_plan = self._group.go(wait=True)

        list_joint_values = self._group.get_current_joint_values()
        # rospy.loginfo('\033[94m' + ">>> Final Joint Values:" + '\033[0m')
        # rospy.loginfo(list_joint_values)

        pose_values = self._group.get_current_pose().pose
        # rospy.loginfo('\033[94m' + ">>> Final Pose:" + '\033[0m')
        # rospy.loginfo(pose_values)

        if (flag_plan == True):
            pass
            # rospy.loginfo(
            #     '\033[94m' + ">>> set_joint_angles() Success" + '\033[0m')
        else:
            pass
            # rospy.logerr(
            #     '\033[94m' + ">>> set_joint_angles() Failed." + '\033[0m')

        return flag_plan

    def hard_set_joint_angles(self, arg_list_joint_angles, arg_max_attempts):

        number_attempts = 0
        flag_success = False
        
        while ( (number_attempts <= arg_max_attempts) and  (flag_success is False) ):
            number_attempts += 1
            flag_success = self.set_joint_angles(arg_list_joint_angles)
            rospy.logwarn("attempts: {}".format(number_attempts) )
            # self.clear_octomap()

    # Destructor

    def __del__(self):
        moveit_commander.roscpp_shutdown()
        rospy.loginfo(
            '\033[94m' + "Object of class Ur5Moveit Deleted." + '\033[0m')

################################################################################  Camera Class ##################################################################################################

class Camera1:

  def __init__(self):
    self.bridge = CvBridge()
    self.image_sub = rospy.Subscriber("/eyrc/vb/camera_1/image_raw", Image,self.callback)
    
    self.pub = rospy.Publisher('my_topic', myMessage , queue_size=10)
    self.my_msg = myMessage()
    #self.my_combo = myModel()

  
  def get_qr_data(self, arg_image):
    ur5 = Ur5Moveit(sys.argv[1])

    global blt_speed

    global lst_joint_angles_straightUp
    global lst_joint_angles_home

    # Row 1
    global lst_joint_angles_00_2
    global lst_joint_angles_00_3
    global lst_joint_angles_01_2
    global lst_joint_angles_01_3
    global lst_joint_angles_02_2
    global lst_joint_angles_02_3

    # Row 2
    global lst_joint_angles_10_2
    global lst_joint_angles_10_3
    global lst_joint_angles_11_2
    global lst_joint_angles_11_3
    global lst_joint_angles_12_2
    global lst_joint_angles_12_3

    # Row 3
    global lst_joint_angles_20_2
    global lst_joint_angles_20_3
    global lst_joint_angles_21_2
    global lst_joint_angles_21_3
    global lst_joint_angles_22_2
    global lst_joint_angles_22_3


    #c = rospy.ServiceProxy('/eyrc/vb/conveyor/set_power',conveyorBeltPowerMsg)

    qr_result = decode(arg_image)

    global package_found
    global msg_ready
    if ( len( qr_result ) > 0 and msg_ready == True):
      for i in range(0,len(qr_result)):

	
	#print("\n Package: ",qr_result[i].data)

	r = qr_result[i].rect

	left = r.left
	top = r.top
	width = r.width
	height = r.height

	if(top>300 and top<400):
		if(left>100 and left<300):
			package_found = "packagen00"
		if(left>300 and left<420):
			package_found = "packagen01"
		if(left>420 and left<600):
			package_found = "packagen02"

	elif(top>400 and top<520):
		if(left>100 and left<300):
			package_found = "packagen10"
		if(left>300 and left<420):
			package_found = "packagen11"
		if(left>420 and left<600):
			package_found = "packagen12"
	
	elif(top>520 and top<670):
		if(left>100 and left<300):
			package_found = "packagen20"
		if(left>300 and left<420):
			package_found = "packagen21"
		if(left>420 and left<600):
			package_found = "packagen22"
		
	elif(top>670 and top<820):
		if(left>100 and left<300):
			package_found = "packagen30"
		if(left>300 and left<420):
			package_found = "packagen31"
		if(left>420 and left<600):
			package_found = "packagen32"
		
	
	#print("Packagen:",package_found)
	#print("\n")
	
	if(package_found == "packagen30" or package_found == "packagen31" or package_found == "packagen32"):
		continue

	elif(package_found == "packagen20" or package_found == "packagen21" or package_found == "packagen22"):
		continue

	else:
		color = qr_result[i].data
		combo = "["+color+","+package_found+"]" 
		self.my_msg.my_model.append(combo)
	
		self.pub.publish(self.my_msg)
		print("Models Array Is: ",self.my_msg.my_model)

		msg_ready = False

		imgCropped = arg_image[top:(top + height), left:(left + width)]
		cv2.imshow("Image: ",imgCropped)

		## Motion ##
		ur5.hard_set_joint_angles(lst_joint_angles_straigntUp, 5)


		############## 1nd Row #################

		if(package_found == "packagen00"):
	    		ur5.hard_set_joint_angles(lst_joint_angles_00_2, 5)
			v = rospy.ServiceProxy('/eyrc/vb/ur5/activate_vacuum_gripper/ur5_1', vacuumGripper)
	    		v(True)
			ur5.hard_set_joint_angles(lst_joint_angles_00_3, 5)

		elif(package_found == "packagen01"):
	    		ur5.hard_set_joint_angles(lst_joint_angles_01_2, 5)
			v = rospy.ServiceProxy('/eyrc/vb/ur5/activate_vacuum_gripper/ur5_1', vacuumGripper)
	    		v(True)
			ur5.hard_set_joint_angles(lst_joint_angles_01_3, 5)
	    	
		elif(package_found == "packagen02"):
	    		ur5.hard_set_joint_angles(lst_joint_angles_02_2, 5)
			v = rospy.ServiceProxy('/eyrc/vb/ur5/activate_vacuum_gripper/ur5_1', vacuumGripper)
	    		v(True)
			ur5.hard_set_joint_angles(lst_joint_angles_02_3, 5)


		############## 2nd Row #################

		elif(package_found == "packagen10"):
	    		ur5.hard_set_joint_angles(lst_joint_angles_10_2, 5)
			v = rospy.ServiceProxy('/eyrc/vb/ur5/activate_vacuum_gripper/ur5_1', vacuumGripper)
	    		v(True)
			ur5.hard_set_joint_angles(lst_joint_angles_10_3, 5)

		elif(package_found == "packagen11"):
	    		ur5.hard_set_joint_angles(lst_joint_angles_11_2, 5)
			v = rospy.ServiceProxy('/eyrc/vb/ur5/activate_vacuum_gripper/ur5_1', vacuumGripper)
	    		v(True)
			ur5.hard_set_joint_angles(lst_joint_angles_11_3, 5)

		elif(package_found == "packagen12"):
	    		ur5.hard_set_joint_angles(lst_joint_angles_12_2, 5)
			v = rospy.ServiceProxy('/eyrc/vb/ur5/activate_vacuum_gripper/ur5_1', vacuumGripper)
	    		v(True)
			ur5.hard_set_joint_angles(lst_joint_angles_12_3, 5)
		

		############## 3rd Row #################

		elif(package_found == "packagen20"):
	    		ur5.hard_set_joint_angles(lst_joint_angles_20_2, 5)
			v = rospy.ServiceProxy('/eyrc/vb/ur5/activate_vacuum_gripper/ur5_1', vacuumGripper)
	    		v(True)
			ur5.hard_set_joint_angles(lst_joint_angles_20_3, 5)

		elif(package_found == "packagen21"):
	    		ur5.hard_set_joint_angles(lst_joint_angles_21_2, 5)
			v = rospy.ServiceProxy('/eyrc/vb/ur5/activate_vacuum_gripper/ur5_1', vacuumGripper)
	    		v(True)
			ur5.hard_set_joint_angles(lst_joint_angles_21_3, 5)

		elif(package_found == "packagen22"):
	    		ur5.hard_set_joint_angles(lst_joint_angles_22_2, 5)
			v = rospy.ServiceProxy('/eyrc/vb/ur5/activate_vacuum_gripper/ur5_1', vacuumGripper)
	    		v(True)
			ur5.hard_set_joint_angles(lst_joint_angles_22_3, 5)
		

		ur5.hard_set_joint_angles(lst_joint_angles_home, 5)
		v(False)
		msg_ready = True

      
  
  def callback(self,data):
    try:
      cv_image = self.bridge.imgmsg_to_cv2(data, "bgr8")
    except CvBridgeError as e:
      rospy.logerr(e)

    (rows,cols,channels) = cv_image.shape
    
    image = cv_image
    image_grey = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    image_thr = cv2.adaptiveThreshold(image_grey,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C,cv2.THRESH_BINARY,51,27)

    im, contours , hierarchy = cv2.findContours(image_thr, cv2.RETR_TREE , cv2.CHAIN_APPROX_SIMPLE)

    with_contours = cv2.drawContours(image, contours,-1,(0,255,0),3)

    # Resize a 720x1280 image to 360x640 to fit it on the screen
    resized_image = cv2.resize(with_contours, (720/2, 1280/2)) 
    cv2.imshow("/eyrc/vb/camera_1/image_raw", resized_image)    
    
    self.get_qr_data(image_thr)
    
    cv2.waitKey(3)

####################################################################################### Ur5 CartesianPath ###################################################################################################

class CartesianPath:

    # Constructor
    def __init__(self, arg_robot_name):


	self._robot_ns = '/'  + arg_robot_name
        self._planning_group = "manipulator"

	self._commander = moveit_commander.roscpp_initialize(sys.argv)
	self._robot = moveit_commander.RobotCommander(robot_description= self._robot_ns + "/robot_description", ns=self._robot_ns)

	self._scene = moveit_commander.PlanningSceneInterface(ns=self._robot_ns)
	self._group = moveit_commander.MoveGroupCommander(self._planning_group, robot_description= self._robot_ns + "/robot_description", ns=self._robot_ns)
	
	self._display_trajectory_publisher = rospy.Publisher( self._robot_ns + '/move_group/display_planned_path', moveit_msgs.msg.DisplayTrajectory, queue_size=1)
	
	self._exectute_trajectory_client = actionlib.SimpleActionClient( self._robot_ns + '/execute_trajectory', moveit_msgs.msg.ExecuteTrajectoryAction)

	self._exectute_trajectory_client.wait_for_server()

	self._planning_frame = self._group.get_planning_frame()
        self._eef_link = self._group.get_end_effector_link()
        self._group_names = self._robot.get_group_names()

	rospy.loginfo('\033[94m' + " >>> Init done." + '\033[0m')

        '''self._planning_group = "ur5_1_planning_group"
        self._commander = moveit_commander.roscpp_initialize(sys.argv)
        self._robot = moveit_commander.RobotCommander()
        self._scene = moveit_commander.PlanningSceneInterface()
        self._group = moveit_commander.MoveGroupCommander(self._planning_group)
        self._display_trajectory_publisher = rospy.Publisher(
            '/move_group/display_planned_path', moveit_msgs.msg.DisplayTrajectory, queue_size=1)

        self._exectute_trajectory_client = actionlib.SimpleActionClient(
            'execute_trajectory', moveit_msgs.msg.ExecuteTrajectoryAction)
        self._exectute_trajectory_client.wait_for_server()

        self._planning_frame = self._group.get_planning_frame()
        self._eef_link = self._group.get_end_effector_link()
        self._group_names = self._robot.get_group_names()'''

        


    def ee_cartesian_translation(self, trans_x, trans_y, trans_z):
        # 1. Create a empty list to hold waypoints
        waypoints = []

        # 2. Add Current Pose to the list of waypoints
        waypoints.append(self._group.get_current_pose().pose)

        # 3. Create a New waypoint
        wpose = geometry_msgs.msg.Pose()
        wpose.position.x = waypoints[0].position.x + (trans_x)  
        wpose.position.y = waypoints[0].position.y + (trans_y)  
        wpose.position.z = waypoints[0].position.z + (trans_z)
        # This to keep EE parallel to Ground Plane
        wpose.orientation.x = -0.5
        wpose.orientation.y = -0.5
        wpose.orientation.z = 0.5
        wpose.orientation.w = 0.5


        # 4. Add the new waypoint to the list of waypoints
        waypoints.append(copy.deepcopy(wpose))


        # 5. Compute Cartesian Path connecting the waypoints in the list of waypoints
        (plan, fraction) = self._group.compute_cartesian_path(
            waypoints,   # waypoints to follow
            0.01,        # Step Size, distance between two adjacent computed waypoints will be 1 cm
            0.0)         # Jump Threshold
        rospy.loginfo("Path computed successfully. Moving the arm.")

        # The reason for deleting the first two waypoints from the computed Cartisian Path can be found here,
        # https://answers.ros.org/question/253004/moveit-problem-error-trajectory-message-contains-waypoints-that-are-not-strictly-increasing-in-time/?answer=257488#post-id-257488
        num_pts = len(plan.joint_trajectory.points)
        if (num_pts >= 3):
            del plan.joint_trajectory.points[0]
            del plan.joint_trajectory.points[1]

        # 6. Make the arm follow the Computed Cartesian Path
        self._group.execute(plan)

    def go_to_pose(self, arg_pose):
    

        pose_values = self._group.get_current_pose().pose
        rospy.loginfo('\033[94m' + ">>> Current Pose:" + '\033[0m')
        rospy.loginfo(pose_values)

        self._group.set_pose_target(arg_pose)
        flag_plan = self._group.go(wait=True)  # wait=False for Async Move

        pose_values = self._group.get_current_pose().pose
        rospy.loginfo('\033[94m' + ">>> Final Pose:" + '\033[0m')
        rospy.loginfo(pose_values)

        list_joint_values = self._group.get_current_joint_values()
        rospy.loginfo('\033[94m' + ">>> Final Joint Values:" + '\033[0m')
        rospy.loginfo(list_joint_values)

        if (flag_plan == True):
            rospy.loginfo('\033[94m' + ">>> go_to_pose() Success" + '\033[0m')
        else:
            rospy.logerr(
                '\033[94m' + ">>> go_to_pose() Failed. Solution for Pose not Found." + '\033[0m')

        return flag_plan
 
    def go_to_predefined_pose(self, arg_pose_name):
        rospy.loginfo('\033[94m' + "Going to Pose: {}".format(arg_pose_name) + '\033[0m')
        self._group.set_named_target(arg_pose_name)
        plan = self._group.plan()
        goal = moveit_msgs.msg.ExecuteTrajectoryGoal()
        goal.trajectory = plan
        self._exectute_trajectory_client.send_goal(goal)
        self._exectute_trajectory_client.wait_for_result()
        rospy.loginfo('\033[94m' + "Now at Pose: {}".format(arg_pose_name) + '\033[0m')

    def set_joint_angles(self, arg_list_joint_angles):

        list_joint_values = self._group.get_current_joint_values()
        rospy.loginfo('\033[94m' + ">>> Current Joint Values:" + '\033[0m')
        rospy.loginfo(list_joint_values)

        self._group.set_joint_value_target(arg_list_joint_angles)
        self._group.plan()
        flag_plan = self._group.go(wait=True)

        list_joint_values = self._group.get_current_joint_values()
        rospy.loginfo('\033[94m' + ">>> Final Joint Values:" + '\033[0m')
        rospy.loginfo(list_joint_values)

        pose_values = self._group.get_current_pose().pose
        rospy.loginfo('\033[94m' + ">>> Final Pose:" + '\033[0m')
        rospy.loginfo(pose_values)

        if (flag_plan == True):
            rospy.loginfo(
                '\033[94m' + ">>> set_joint_angles() Success" + '\033[0m')
        else:
            rospy.logerr(
                '\033[94m' + ">>> set_joint_angles() Failed." + '\033[0m')

        return flag_plan


    # Destructor
    def _del_(self):
        moveit_commander.roscpp_shutdown()
        rospy.loginfo(
            '\033[94m' + "Object of class CartesianPath Deleted." + '\033[0m')

#################################################################################### Subscriber Function ####################################################################################################

def function_callback(msg):
   global msg_received_bySub
   global subscriber_msg
   global message_reveived
   global count
   if(msg_received_bySub == True):
	subscriber_msg = msg
	message_reveived = True
	msg_received_bySub = False
   print("\n")


####################################################################################### Logical Camera 2 ####################################################################################################

def logical_camera2_callback_function(msg):
  global pkg_detected_byLc
  global blt_speed
  pkg_detected_byLc= msg.models
  '''for model in msg.models:
	print("Model found: ",model.type)'''
  c = rospy.ServiceProxy('/eyrc/vb/conveyor/set_power',conveyorBeltPowerMsg)
  if(blt_speed == 1):
	c(0)
  elif(blt_speed == 2 or blt_speed == -1):
	c(100)


#####################################################  Main Function #################################################################################################


def main(args):

  global pkg_detected_byLc
  global subscriber_msg
  global blt_speed

  global msg_received_bySub

  global message_reveived

  
  rospy.init_node('node_eg1_read_camera', anonymous=True)

  ic = Camera1()

  ur5 = CartesianPath(sys.argv[2])
  
  rospy.Subscriber("/eyrc/vb/logical_camera_2", LogicalCameraImage, logical_camera2_callback_function)

  rospy.Subscriber("my_topic" , myMessage , function_callback)  

  # We have to trigger the home pose of UR5_2
  ur5.go_to_pose(ur5_2_home_pose)


  # For green
  lst_joint_angles_1 = [math.radians(-30),
                        math.radians(-30),
                        math.radians(0),
                        math.radians(0),
                        math.radians(0),
                        math.radians(0)]

  # For Yellow
  lst_joint_angles_2 = [math.radians(-100),
                        math.radians(0),
                        math.radians(-35),
                        math.radians(0),
                        math.radians(0),
                        math.radians(0)]

  while not rospy.is_shutdown():
	if(len(pkg_detected_byLc)>0):
		for pkg in pkg_detected_byLc:
			print("Package detected by LC: ",pkg.type)
			'''if(message_reveived == True):
				print("Message is received by subscriber")
				print("SUB IN MAIN: ",subscriber_msg)

				for model in subscriber_msg.my_model:

					bracket_removed = model.replace(']','').replace('[','')
   					message = bracket_removed.replace('"','').split(",")

					print("MODEL MSG IN SUB MSG: ",message)
					if(pkg.type == message[1]):
						print("MATCHED PACKAGE")
						if(pkg.pose.position.y / 0.046 < 0 ):

							blt_speed=1
							print("package in center position")
							v = rospy.ServiceProxy('/eyrc/vb/ur5/activate_vacuum_gripper/ur5_2', vacuumGripper)
					    		v(True)		
						       	print("NOW PICKING BLOCK")
							if(message[0] == "red"):
								print("NOW WE CAN MOVE TO RED BOX")
								# Move to RED BOX
								ur5.ee_cartesian_translation(1.5, 1, 0.5)
								blt_speed=2
				 				v(False)
								msg_received_bySub = True
								ur5.go_to_pose(ur5_2_home_pose)

							elif(message[0] == "green"):
								print("NOW WE CAN MOVE TO GREEN BOX")
								# Move to GREEN BOX
								ur5.set_joint_angles(lst_joint_angles_2)
				 				v(False)
								blt_speed=2
								msg_received_bySub = True
								ur5.go_to_pose(ur5_2_home_pose)

							elif(message[0] == "yellow"):
								print("NOW WE CAN MOVE TO YELLOW BOX")
								# Move to YELLOW BOX
								ur5.set_joint_angles(lst_joint_angles_1)
				 				v(False)
								blt_speed=2
								msg_received_bySub = True
								ur5.go_to_pose(ur5_2_home_pose)'''


if __name__ == '__main__':
    main(sys.argv)
